#ifndef _KEY_H
#define _KEY_H

unsigned char KeyDownProcess(void);
unsigned char KeyUpProcess(void);
unsigned char KeySwitchProcess(void);


#endif




