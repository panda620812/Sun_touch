/*************************************************************************************************************************
 * Created by: Holtek Touch MCU Workshop, Version 3.5.0.0
 * TKS_GLOBE_VARIES.H
 * 03:02:23 PM Saturday, December 16, 2017
*************************************************************************************************************************/
#include <BS84B08A-3.h>
#define _BS84B08A_
#define _V413_
#define SystemClock     0
// Components' settings ...
//	'LEDX4' 
